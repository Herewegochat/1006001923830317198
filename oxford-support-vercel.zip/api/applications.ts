import { apply } from "../lib/applications";
export const config = { runtime: "edge" };
export default function handler(request: Request) {
  return apply(request, process.env.DISCORD_WEBHOOK_URL);
}
